# Gruvbox Theme for GTK
Created with [oomox](https://github.com/actionless/oomox) based on [Gruvbox](https://github.com/morhetz/gruvbox) colors

## Sample Screenshots

Evince

![evince](evince.png)

Sample

![example](example.png)

